package ab08;

public class Aufgabe4 {
	public static void main(String[] args){
		
	
	
	
	String wort;
	
	
	wort=IO.readString("Bitte Wort eingeben: ");
	

	
	int i=0;;
	while (wort.length() > i ){
	
	System.out.println(wort);
	i++;
	}
	
	
		
		
	}

	}

