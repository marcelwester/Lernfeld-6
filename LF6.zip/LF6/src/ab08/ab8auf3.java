package ab08;



public class ab8auf3 {
	
	public static void main(String[]args){
		
		
		int x=0;
		int y=0;
		
		
		
		do {
			x=IO.readChar("Druecken Sie eine Richtungstaste(o,w,s,b=beenden: ");
			y=IO.readChar("Druecken Sie eine Richtungstaste(o,w,s,b=beenden: ");
			
		}
		while (x== 'o');
			x=11;
			y=10;
		
		
		
		
	}

}
